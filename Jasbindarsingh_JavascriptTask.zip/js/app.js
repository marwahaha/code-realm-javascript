/**
 * Created by satnam on 6/7/19.
 */

angular.module("todotask",[]);

angular.module('todotask')
    .controller('MainController', function () {

        var ctrl = this;
        ctrl.taskList = [];
        ctrl.taskObj = {
            taskName: '',
            isCompleted: false
        };

        ctrl.init = function () {
            ctrl.taskList = getStore();
        };

        ctrl.addTask = function () {
            addTaskInStore(ctrl.taskObj);
            ctrl.taskList = getStore();
        };

        ctrl.deleteTask = function (task) {
            deleteTask(task);
            ctrl.taskList = getStore();
        };

        ctrl.updateTask = function (task) {
            updateTask(task);
            ctrl.taskList = getStore();
        };



});

