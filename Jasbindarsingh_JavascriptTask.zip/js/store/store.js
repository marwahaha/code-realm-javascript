// The core logic of the store will go here.



const storeObj = {
  tasks:[{
      taskName:'test',
      isCompleted: false
  }]
};

function getStore() {
    //return immutable store
    let mergeArgs = function (propt) {
        extendedTaskObj[prop] = storeObj[prop];
    };

    let extendedTaskObj = {};
    for(var prop in storeObj){
        if(storeObj.hasOwnProperty(prop)){
            mergeArgs(prop);
        }
    }

    return extendedTaskObj;
}

function addTaskInStore(task) {
    let newTask = {...task}
    storeObj.tasks.push(newTask);
}

function deleteTask(task){
    for(let i=0; i<storeObj.tasks.length; i++){
        if(task.taskName == storeObj.tasks[i].taskName){
            storeObj.tasks.splice(i,1);
        }
    }
}

function updateTask(task){
    //only updates status
    for(let i=0; i<storeObj.tasks.length; i++){
        if(task.taskName == storeObj.tasks[i].taskName){
            storeObj.tasks.splice(i,1,task);
        }
    }

}

